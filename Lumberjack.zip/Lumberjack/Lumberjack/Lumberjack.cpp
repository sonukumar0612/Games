#include<SFML/Graphics.hpp>
#include<sstream>
#include <iostream>
#include <SFML/Audio.hpp>

using namespace sf;

void refurbishBranches(int seed);
const int BRANCH_COUNT = 6;
Sprite branches[BRANCH_COUNT];
enum class side {
	LEFT,
	RIGHT,
	NONE
};
side branchLocation[BRANCH_COUNT];

int main()
{
	VideoMode videoMode(1366, 768);
	RenderWindow window(videoMode, "LumberJack!!!", Style::Fullscreen);
	Texture textureBackground;
	textureBackground.loadFromFile("graphics/background_71_perfect.png");
	Sprite spriteBackground;
	spriteBackground.setTexture(textureBackground);
	spriteBackground.setPosition(0, 0);
	Texture textureTree;
	textureTree.loadFromFile("graphics/tree_71.png");
	Sprite sTree;
	sTree.setTexture(textureTree);
	sTree.setPosition(575, 0);
	//insect 1
	Texture textureInsect;
	textureInsect.loadFromFile("graphics/insect_71_1.png");
	Sprite spriteInsect;
	spriteInsect.setTexture(textureInsect);
	spriteInsect.setPosition(0, 568);
	bool insectActive = false;
	float insectSpeed = 0.0f;
	//insect 2
	Texture textureInsect2;
	textureInsect2.loadFromFile("graphics/insect_2_71.png");
	Sprite spriteInsect2;
	spriteInsect2.setTexture(textureInsect2);
	spriteInsect2.setPosition(0, 600);
	bool insectActive2 = false;
	float insectSpeed2 = 0.0f;

	//insect 3
	Texture textureInsect3;
	textureInsect3.loadFromFile("graphics/mosquito.png");
	Sprite spriteInsect3;
	spriteInsect3.setTexture(textureInsect3);
	spriteInsect3.setPosition(0, 650);
	bool insectActive3 = false;
	float insectSpeed3 = 0.0f;
	//insect 4
	Texture textureInsect4;
	textureInsect4.loadFromFile("graphics/insect_71_4.png");
	Sprite spriteInsect4;
	spriteInsect4.setTexture(textureInsect4);
	spriteInsect4.setPosition(0, 600);
	bool insectActive4 = false;
	float insectSpeed4 = 0.0f;


	Texture textureSky;
	Texture textureSky2;
	Texture textureSky3;
	Texture textureSkyArray[6];
	textureSky.loadFromFile("graphics/sky_71_1.png");
	textureSky2.loadFromFile("graphics/sky_71_2.png");
	textureSky3.loadFromFile("graphics/sky_71_3.png");
	textureSkyArray[0].loadFromFile("graphics/sky_71_2.png");
	textureSkyArray[1].loadFromFile("graphics/sky_71_3.png");
	textureSkyArray[2].loadFromFile("graphics/sky_71_1.png");
	textureSkyArray[3].loadFromFile("graphics/sky_71_2.png");
	textureSkyArray[4].loadFromFile("graphics/sky_71_3.png");
	textureSkyArray[5].loadFromFile("graphics/sky_71_1.png");
	Sprite spriteSky1;
	Sprite spriteSky2;
	Sprite spriteSky3;
	Sprite spriteSkyArray[6];
	for (int i = 0; i < 6; i++)
		spriteSkyArray[i].setTexture(textureSkyArray[i]);
	spriteSky1.setTexture(textureSky);
	spriteSky2.setTexture(textureSky2);
	spriteSky3.setTexture(textureSky3);
	spriteSky1.setPosition(0, 0);
	spriteSky2.setPosition(350, 106);
	spriteSky3.setPosition(700, 213);
	for (int i = 0; i < 6; i++)
		spriteSkyArray[i].setPosition(i * 175, i * 40);
	bool sky1Active = false;
	bool sky2Active = false;
	bool sky3Active = false;
	bool skyActiveArray[6];
	for (int i = 0; i < 6; i++)
		skyActiveArray[i] = false;
	float sky1Speed = 0.0f;
	float sky2Speed = 0.0f;
	float sky3Speed = 0.0f;
	float skySpeedArray[6];
	for (int i = 0; i < 6; i++)
		skySpeedArray[i] = 0.0f;
	Clock clock;

	RectangleShape timeBar;
	float timeBarstartWidth = 280;
	float timeBarHeight = 15;
	timeBar.setSize(Vector2f(timeBarstartWidth, timeBarHeight));
	timeBar.setFillColor(Color::Red);
	timeBar.setPosition((1366 / 2) - timeBarstartWidth / 2, 696);

	Time gameTimeTotal;
	float timeRemaining = 6.0f;
	float timeBarWidthPerSecond = timeBarstartWidth / timeRemaining;


	bool paused = true;

	int score = 0;
	sf::Text textMessage;
	sf::Text textScore;
	Font font;
	font.loadFromFile("fonts/KOMIKAP_.ttf");

	textMessage.setFont(font);
	textScore.setFont(font);

	textMessage.setString("Press Enter to start!");
	textScore.setString("Score = 0");

	textMessage.setCharacterSize(75);
	textScore.setCharacterSize(100);

	textMessage.setFillColor(Color::White);
	textScore.setFillColor(Color::Red);

	FloatRect textRect = textMessage.getLocalBounds();
	textMessage.setOrigin(textRect.left + textRect.width / 2.0f, textRect.top + textRect.height / 2.0f);
	textMessage.setPosition(1366 / 2.0f, 768 / 2.0f);
	textScore.setPosition(20, 20);

	Texture textureBranch;
	textureBranch.loadFromFile("graphics/branch_d.png");
	for (int i = 0; i < BRANCH_COUNT - 2; i++)
	{
		branches[i].setTexture(textureBranch);
		branches[i].setPosition(-1420, -1420);
		branches[i].setOrigin(160, 14);
	}
	Texture textureBranch1;
	textureBranch1.loadFromFile("graphics/branch_71.png");
	for (int i = 4; i < BRANCH_COUNT; i++)
	{
		branches[i].setTexture(textureBranch1);
		branches[i].setPosition(-1420, -1420);
		branches[i].setOrigin(160, 14);
	}

	Texture texturePlayer;
	texturePlayer.loadFromFile("graphics/player_71_1.png");
	Sprite sPlayer;
	sPlayer.setTexture(texturePlayer);
	sPlayer.setPosition(412, 511);

	side playerSide = side::LEFT;

	Texture textureRIP;
	textureRIP.loadFromFile("graphics/rip_71.png");
	Sprite spriteRestInPeace;
	spriteRestInPeace.setTexture(textureRIP);
	spriteRestInPeace.setPosition(426, 611);

	Texture textureChopper;
	textureChopper.loadFromFile("graphics/chopper_71.png");
	Sprite sChopper;
	sChopper.setTexture(textureChopper);
	sChopper.setPosition(497, 589);

	const float chopper_POSITION_LEFT = 490;
	const float chopper_POSITION_RIGHT = 763;

	Texture textureLog;
	textureLog.loadFromFile("graphics/log_71.png");
	Sprite spriteStump;
	spriteStump.setTexture(textureLog);
	spriteStump.setPosition(575, 511);

	bool logActive = false;
	float logSpeedX = 710;
	float logSpeedY = -1065;

	bool acceptInput = false;

	SoundBuffer scrapBuffer;
	scrapBuffer.loadFromFile("sound/scrap.wav");
	Sound scrap;
	scrap.setBuffer(scrapBuffer);

	SoundBuffer killedBuffer;
	killedBuffer.loadFromFile("sound/killed.wav");
	Sound killed;
	killed.setBuffer(killedBuffer);

	SoundBuffer reviveBuffer;
	reviveBuffer.loadFromFile("sound/revive.wav");
	Sound revive;
	revive.setBuffer(reviveBuffer);

	while (window.isOpen())
	{
		Event event;
		while (window.pollEvent(event))
		{


			if (event.type == Event::KeyReleased && !paused)
			{
				acceptInput = true;

				sChopper.setPosition(1420,
					sChopper.getPosition().y);
			}

		}
		if (Keyboard::isKeyPressed(Keyboard::Escape))
		{
			window.close();
		}
		if (Keyboard::isKeyPressed(Keyboard::Return))
		{
			paused = false;
			score = 0;
			timeRemaining = 5;

			for (int i = 1; i < BRANCH_COUNT; i++)
			{
				branchLocation[i] = side::NONE;
			}

			spriteRestInPeace.setPosition(479, 1420);

			sPlayer.setPosition(412, 511);

			acceptInput = true;

		}
		if (acceptInput)
		{
			if (Keyboard::isKeyPressed(Keyboard::Right))
			{
				playerSide = side::RIGHT;

				score++;
				timeRemaining += (2 / (score)) + .2;

				sChopper.setPosition(chopper_POSITION_RIGHT,
					sChopper.getPosition().y);

				sPlayer.setPosition(852, 511);
				refurbishBranches(score);

				spriteStump.setPosition(575, 511);
				logSpeedX = -3550;
				logActive = true;


				acceptInput = false;

				scrap.play();

			}

			if (Keyboard::isKeyPressed(Keyboard::Left))
			{
				playerSide = side::LEFT;

				score++;

				timeRemaining += (2 / (score)) + .2;

				sChopper.setPosition(chopper_POSITION_LEFT,
					sChopper.getPosition().y);


				sPlayer.setPosition(412, 511);

				refurbishBranches(score);

				spriteStump.setPosition(575, 511);
				logSpeedX = 3550;
				logActive = true;


				acceptInput = false;

				scrap.play();

			}

		}
		if (!paused)
		{
			Time dt = clock.restart();

			timeRemaining -= dt.asSeconds();
			timeBar.setSize(Vector2f(timeBarWidthPerSecond * timeRemaining, timeBarHeight));

			if (timeRemaining <= 0.0f)
			{
				paused = true;
				textMessage.setString("Out of Time!!!");
				FloatRect textRect = textMessage.getLocalBounds();
				textMessage.setOrigin(textRect.left + textRect.width / 2.0f, textRect.top + textRect.height / 2.0f);
				textMessage.setPosition(1366 / 2.0f, 768 / 2.0f);

				revive.play();
			}

			if (!insectActive)
			{
				srand((int)time(0) * 10);
				insectSpeed = (rand() % 100) + 100;
				srand((int)time(0) * 10);
				float height = (rand() % 355) + 355;
				spriteInsect.setPosition(1366, height);
				insectActive = true;
			}
			else
			{
				if (dt.asMicroseconds() % 2 == 0)
					spriteInsect.setPosition(spriteInsect.getPosition().x - (insectSpeed*dt.asSeconds()), spriteInsect.getPosition().y + 0.908);
				else
					spriteInsect.setPosition(spriteInsect.getPosition().x - (insectSpeed*dt.asSeconds()), spriteInsect.getPosition().y - 0.9);
				if (spriteInsect.getPosition().x <= -171 || spriteInsect.getPosition().y > 768)
					insectActive = false;


			}
			if (!insectActive2)
			{
				srand((int)time(0) * 10);
				insectSpeed2 = (rand() % 50) + 50;
				srand((int)time(0) * 10);
				float height = (rand() % 355) + 455;
				spriteInsect2.setPosition(0, height + 100);
				insectActive2 = true;
			}
			else
			{
				if (dt.asMicroseconds() % 2 != 0)
					spriteInsect2.setPosition(spriteInsect2.getPosition().x + (insectSpeed2*dt.asSeconds()), spriteInsect2.getPosition().y + 0.503);
				else
					spriteInsect2.setPosition(spriteInsect2.getPosition().x + (insectSpeed2*dt.asSeconds()), spriteInsect2.getPosition().y - 0.5);
				if (spriteInsect2.getPosition().x >= 1400 || spriteInsect2.getPosition().y > 768)
					insectActive2 = false;


			}

			//insect 3 movement

			if (!insectActive4)
			{
				srand((int)time(0) * 10);
				insectSpeed4 = (rand() % 30) + 30;
				srand((int)time(0) * 10);
				float height = (rand() % 200) + 600;
				spriteInsect4.setPosition(1366, height);
				insectActive4 = true;
			}
			else
			{
				if (dt.asMicroseconds() % 2 == 0)
					spriteInsect4.setPosition(spriteInsect4.getPosition().x - (insectSpeed4*dt.asSeconds()), spriteInsect4.getPosition().y + 0.303);
				else
					spriteInsect4.setPosition(spriteInsect4.getPosition().x - (insectSpeed4*dt.asSeconds()), spriteInsect4.getPosition().y - 0.3);
				if (spriteInsect4.getPosition().x <= -171 || spriteInsect4.getPosition().y > 768)
					insectActive4 = false;


			}
			if (!insectActive3)
			{
				srand((int)time(0) * 10);
				insectSpeed3 = (rand() % 50) + 20;
				srand((int)time(0) * 10);
				float height = (rand() % 20) + 400;
				spriteInsect3.setPosition(0, height + 130);
				insectActive3 = true;
			}
			else
			{
				if (dt.asMicroseconds() % 2 == 0)
					spriteInsect3.setPosition(spriteInsect3.getPosition().x + (insectSpeed3*dt.asSeconds()), spriteInsect3.getPosition().y + 0.305);
				else
					spriteInsect3.setPosition(spriteInsect3.getPosition().x + (insectSpeed3*dt.asSeconds()), spriteInsect3.getPosition().y - 0.3);
				if (spriteInsect3.getPosition().x >= 1400 || spriteInsect3.getPosition().y > 768)
					insectActive3 = false;


			}

			//insect 4 movement end



			if (!sky1Active)
			{

				srand((int)time(0) * 7);
				sky1Speed = (rand() % 30) + 60;

				srand((int)time(0) * 7);
				float height = (rand() % 106);
				spriteSky1.setPosition(-142, height);
				sky1Active = true;


			}
			else
			{

				spriteSky1.setPosition(
					spriteSky1.getPosition().x +
					(sky1Speed * dt.asSeconds()),
					spriteSky1.getPosition().y);

				if (spriteSky1.getPosition().x > 1366)
				{
					sky1Active = false;
				}
			}
			if (!sky2Active)
			{

				srand((int)time(0) * 14);
				sky2Speed = (rand() % 20) + 70;

				srand((int)time(0) * 14);
				float height = (rand() % 213) - 106;
				spriteSky2.setPosition(-142, height);
				sky2Active = true;


			}
			else
			{

				spriteSky2.setPosition(
					spriteSky2.getPosition().x +
					(sky2Speed * dt.asSeconds()),
					spriteSky2.getPosition().y);

				if (spriteSky2.getPosition().x > 1366)
				{
					sky2Active = false;
				}
			}

			if (!sky3Active)
			{

				srand((int)time(0) * 21);
				sky3Speed = (rand() % 10) + 70;
				srand((int)time(0) * 21);
				float height = (rand() % 316) - 106;
				spriteSky3.setPosition(-142, height);
				sky3Active = true;


			}
			else
			{

				spriteSky3.setPosition(
					spriteSky3.getPosition().x +
					(sky3Speed * dt.asSeconds()),
					spriteSky3.getPosition().y);

				if (spriteSky3.getPosition().x > 1366)
				{
					sky3Active = false;
				}
			}

			for (int i = 0; i < 6; i++)
			{
				if (!skyActiveArray[i])
				{

					srand((int)time(0) * 21 + i * 3);
					skySpeedArray[i] = (rand() % 20) + 15 + (i * 10);

					srand((int)time(0) * (21 + i * 2));
					float height = (rand() % 316) / (i + 1) + 70;
					spriteSkyArray[i].setPosition(-142, height + (i * 5));
					skyActiveArray[i] = true;
				}
				else
				{

					spriteSkyArray[i].setPosition(
						spriteSkyArray[i].getPosition().x +
						(skySpeedArray[i] * dt.asSeconds()),
						spriteSkyArray[i].getPosition().y);

					if (spriteSkyArray[i].getPosition().x > 1366)
					{
						skyActiveArray[i] = false;
					}
				}
			}
			std::stringstream ss;
			ss << "Score = " << score;
			textScore.setString(ss.str());

			for (int i = 0; i < BRANCH_COUNT; i++)
			{
				float height = i * 107;
				if (branchLocation[i] == side::LEFT)
				{
					branches[i].setPosition(433, height);
					branches[i].setRotation(180);
				}
				else if (branchLocation[i] == side::RIGHT)
				{
					branches[i].setPosition(944.3, height);
					branches[i].setRotation(0);
				}
				else
				{
					branches[i].setPosition(3000, height);
				}
			}
			if (logActive)
			{

				spriteStump.setPosition(
					spriteStump.getPosition().x + (logSpeedX * dt.asSeconds()),
					spriteStump.getPosition().y + (logSpeedY * dt.asSeconds()));

				if (spriteStump.getPosition().x < -71 ||
					spriteStump.getPosition().x > 1420)
				{
					logActive = false;
					spriteStump.setPosition(575, 511);
				}
			}
			if (branchLocation[5] == playerSide)
			{
				paused = true;
				acceptInput = false;

				spriteRestInPeace.setPosition(373, 540);

				sPlayer.setPosition(1420, 469);

				textMessage.setString("SQUISHED!!");

				FloatRect textRect = textMessage.getLocalBounds();

				textMessage.setOrigin(textRect.left +
					textRect.width / 2.0f,
					textRect.top + textRect.height / 2.0f);

				textMessage.setPosition(1366 / 2.0f,
					768 / 2.0f);

				killed.play();


			}

		}
		window.clear();

		window.draw(spriteBackground);
		window.draw(spriteSky1);
		window.draw(spriteSky2);
		window.draw(spriteSky3);
		for (int i = 0; i < 6; i++)
			window.draw(spriteSkyArray[i]);
		for (int i = 0; i < BRANCH_COUNT; i++)
		{
			window.draw(branches[i]);
		}
		window.draw(sTree);
		window.draw(sPlayer);
		window.draw(sChopper);
		window.draw(spriteStump);

		window.draw(spriteRestInPeace);
		window.draw(spriteInsect);
		window.draw(spriteInsect2);
		window.draw(spriteInsect3);
		window.draw(spriteInsect4);
		if (paused)
		{
			window.draw(textMessage);
		}
		window.draw(textScore);
		window.draw(timeBar);
		window.display();
	}
	return 0;
}
void refurbishBranches(int seed)
{
	for (int j = BRANCH_COUNT - 1; j > 0; j--)
	{
		branchLocation[j] = branchLocation[j - 1];
	}

	srand((int)time(0) + seed);
	int r = (rand() % 5);
	switch (r)
	{
	case 0:
		branchLocation[0] = side::LEFT;
		break;
	case 1:
		branchLocation[0] = side::RIGHT;
		break;
	default:
		branchLocation[0] = side::NONE;
		break;
	}
}

